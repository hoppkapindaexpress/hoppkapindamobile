import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../routes/app_router.dart';
import '../../widgets/widgets.dart';
import 'auth_provider.dart';

const _kDomains = ['gmail.com', 'outlook.com', 'hotmail.com', 'yahoo.com', 'icloud.com', 'hopp.com', 'hopp.com.tr'];

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _password = TextEditingController();
  String _selectedDomain = _kDomains[0];
  bool _obscurePassword = true;

  late final AnimationController _bannerController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  );
  late final Animation<Offset> _bannerSlide = Tween<Offset>(
    begin: const Offset(0, -1.0),
    end: Offset.zero,
  ).animate(CurvedAnimation(
    parent: _bannerController,
    curve: Curves.easeOutCubic,
  ));
  late final Animation<double> _bannerFade = CurvedAnimation(
    parent: _bannerController,
    curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
  );

  @override
  void initState() {
    super.initState();
    _bannerController.forward();
  }

  @override
  void dispose() {
    _bannerController.dispose();
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  String get _fullEmail => '${_username.text.trim()}@$_selectedDomain';

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final ok = await ref
        .read(authProvider.notifier)
        .login(_fullEmail, _password.text);
    if (!mounted) return;
    if (ok) {
      final user = ref.read(authProvider).user;
      if (user?.isCourier == true) {
        context.go(AppRoutes.courierOrders);
      } else {
        context.go(AppRoutes.home);
      }
    } else {
      final error = ref.read(authProvider).error;
      AppToast.show(context, error ?? 'Giriş başarısız');
    }
  }

  void _continueAsGuest() => context.go(AppRoutes.home);

  @override
  Widget build(BuildContext context) {
    final loading = ref.watch(authProvider).loading;
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            AppSpacing.screenPadding,
            AppSpacing.xs,
            AppSpacing.screenPadding,
            bottomInset + AppSpacing.md,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    // ── Logo ───────────────────────────────────────
                    FadeTransition(
                      opacity: _bannerFade,
                      child: SlideTransition(
                        position: _bannerSlide,
                        child: Center(
                          child: SizedBox(
                            height: 170,
                            child: Image.asset(
                              'assets/images/logo_hopp.png',
                              fit: BoxFit.contain,
                              errorBuilder: (_, __, ___) => Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  gradient: AppColors.brandGradient,
                                  borderRadius: AppRadius.lgAll,
                                  boxShadow: AppShadows.brandGlow,
                                ),
                                child: const Icon(Icons.delivery_dining_rounded,
                                    size: 60, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xl),

                    // ── E-posta: kullanıcı adı + domain dropdown ───
                    Text('E-posta', style: AppTypography.labelMedium),
                    const SizedBox(height: AppSpacing.xs),
                    TextFormField(
                      controller: _username,
                      keyboardType: TextInputType.emailAddress,
                      style: AppTypography.bodyLarge,
                      validator: (v) =>
                          (v == null || v.trim().isEmpty)
                              ? 'Kullanıcı adını gir'
                              : null,
                      decoration: InputDecoration(
                        hintText: 'kullaniciadi',
                        prefixIcon: const Icon(Icons.mail_outline_rounded,
                            color: AppColors.secondary, size: 22),
                        suffixIcon: _DomainDropdown(
                          value: _selectedDomain,
                          domains: _kDomains,
                          onChanged: (d) =>
                              setState(() => _selectedDomain = d),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.md),

                    // ── Şifre ──────────────────────────────────────
                    _ColoredTextField(
                      label: 'Şifre',
                      hint: '••••••',
                      controller: _password,
                      prefixIcon: Icons.lock_outline_rounded,
                      iconColor: const Color(0xFF2D7FF9),
                      obscure: _obscurePassword,
                      onToggleObscure: () =>
                          setState(() => _obscurePassword = !_obscurePassword),
                      validator: (v) =>
                          (v == null || v.length < 6)
                              ? 'En az 6 karakter'
                              : null,
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () =>
                            context.push(AppRoutes.forgotPassword),
                        child: Text(
                          'Şifremi unuttum',
                          style: AppTypography.labelMedium
                              .copyWith(color: AppColors.primary),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.sm),

              // ── Giriş Yap ──────────────────────────────────
              AppButton(
                label: 'Giriş Yap',
                variant: AppButtonVariant.gradient,
                loading: loading,
                onPressed: _login,
              ),
              const SizedBox(height: AppSpacing.md),

              // ── Kayıt Ol ───────────────────────────────────
              AppButton(
                label: 'HESAP OLUŞTUR',
                variant: AppButtonVariant.outline,
                icon: Icons.person_add_outlined,
                onPressed: () => context.push(AppRoutes.register),
              ),
              const SizedBox(height: AppSpacing.md),

              // ── Misafir ────────────────────────────────────
              _GuestButton(onTap: _continueAsGuest),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Domain dropdown (suffix widget) ─────────────────────────────────────────
class _DomainDropdown extends StatelessWidget {
  const _DomainDropdown({
    required this.value,
    required this.domains,
    required this.onChanged,
  });

  final String value;
  final List<String> domains;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isDense: true,
          icon: const Icon(Icons.arrow_drop_down_rounded,
              color: AppColors.primary, size: 20),
          style: AppTypography.bodyMedium.copyWith(color: AppColors.primary),
          borderRadius: AppRadius.mdAll,
          items: domains
              .map((d) => DropdownMenuItem(
                    value: d,
                    child: Text('@$d',
                        style: AppTypography.bodySmall
                            .copyWith(color: AppColors.primary)),
                  ))
              .toList(),
          onChanged: (d) {
            if (d != null) onChanged(d);
          },
        ),
      ),
    );
  }
}

// ── Renkli ikonlu text field ─────────────────────────────────────────────────
class _ColoredTextField extends StatelessWidget {
  const _ColoredTextField({
    required this.label,
    required this.controller,
    required this.prefixIcon,
    required this.iconColor,
    this.hint,
    this.keyboardType,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  final String label;
  final String? hint;
  final TextEditingController controller;
  final IconData prefixIcon;
  final Color iconColor;
  final TextInputType? keyboardType;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTypography.labelMedium),
        const SizedBox(height: AppSpacing.xs),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          obscureText: obscure,
          validator: validator,
          style: AppTypography.bodyLarge,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(prefixIcon, color: iconColor, size: 22),
            suffixIcon: onToggleObscure != null
                ? IconButton(
                    icon: Icon(
                      obscure
                          ? Icons.visibility_off_rounded
                          : Icons.visibility_rounded,
                      color: AppColors.softGray,
                      size: 22,
                    ),
                    onPressed: onToggleObscure,
                  )
                : null,
          ),
        ),
      ],
    );
  }
}

// ── Misafir butonu ───────────────────────────────────────────────────────────
class _GuestButton extends StatefulWidget {
  const _GuestButton({required this.onTap});
  final VoidCallback onTap;

  @override
  State<_GuestButton> createState() => _GuestButtonState();
}

class _GuestButtonState extends State<_GuestButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: AppRadius.mdAll,
            gradient: LinearGradient(
              colors: [
                AppColors.primary.withOpacity(0.08),
                AppColors.primaryLight.withOpacity(0.12),
              ],
            ),
            border: Border.all(
              color: AppColors.primary.withOpacity(0.5),
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  gradient: AppColors.brandGradient,
                  borderRadius: AppRadius.smAll,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.30),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(Icons.person_rounded,
                    size: 22, color: Colors.white),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Misafir olarak devam et',
                      style: AppTypography.titleMedium
                          .copyWith(color: AppColors.primary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Uygulamayı Keşfet',
                      style: AppTypography.bodySmall.copyWith(
                          color: AppColors.primary.withOpacity(0.65)),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios_rounded,
                  size: 15, color: AppColors.primary.withOpacity(0.6)),
            ],
          ),
        ),
      ),
    );
  }
}
